window.addEventListener('DOMContentLoaded', function (e) {


    var buttons = document.getElementsByTagName('button');
    console.log(buttons.length);


    for (let i = 0; i < buttons.length; i++) {
//Gets the answers through json

        if (buttons[i].value == "show_answers") {

            buttons[i].addEventListener('click', function () {

                var id = buttons[i].getAttribute('data-id');

                fetch("/ShowAnswerServlet?index-question=" + id)

                    .then(response => {

                        if (response.ok) {
                            return response.json();
                        } else {
                           window.alert("Error not expected, try again later ");
                        }

                    }).then(json => displayAnswer(json, id)).catch(
                    (function(){
                        window.alert("Error not expected, try again later ");
                    })
                );

            });

        }
//Prints the answers to the question on the browser
        function displayAnswer(json, id) {

            const answerContainer = document.getElementById("answer-" + id);


             var i =1;
            for (let answerObject of json) {

                answerContainer.innerHTML += i + ". [" + answerObject.userName + "]: "
                    + answerObject.title + "<br>";
                i++;
            }

        }

//Handles the answer button
        if (buttons[i].value == "answer_q") {

            buttons[i].addEventListener('click', function () {

                var id = buttons[i].getAttribute('data-id');

                window.location.replace("/FormServlet?numq=" + id);

                console.log("DEBO");

                console.log("the id is " + id);
            });

        }
    }


});

