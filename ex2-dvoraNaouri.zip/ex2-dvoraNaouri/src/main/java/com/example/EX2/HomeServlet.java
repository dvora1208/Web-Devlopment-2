package com.example.EX2;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The type Servlet 2.
 */
@WebServlet(name = "Servlet2", value = "/QustionHome")
public class HomeServlet extends HttpServlet {

    /**
     * The constant TITLE. here we read from the file the question and we insert it
     * in the array list of question
     *this is the landing page
     */
    public static final String TITLE = "Questions";

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        String questionsFile = getServletContext().getInitParameter("questionsFile");

        InputStream resourceAsStream = getServletContext().getResourceAsStream(questionsFile);

        Scanner scanner = new Scanner(resourceAsStream);

        List<Question> arrayQuestionsAnswer = new ArrayList<>();

        int currentCells = 0;

        while (scanner.hasNextLine()) {
            String nextLine = scanner.nextLine();


            arrayQuestionsAnswer.add(new Question(currentCells + 1, nextLine));

            currentCells++;
        }

        config.getServletContext().setAttribute("ShowQuetion", arrayQuestionsAnswer);

    }

    @Override


    /**
     * here we print the html qustion and botton on the browser
     *
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {


            Writer out = response.getWriter();

            response.setHeader("Content-Type", "text/html");


            Object showQuetion = getServletContext().getAttribute("ShowQuetion");

            ArrayList<Question> questionArrayList = (ArrayList<Question>) showQuetion;

            int numq=0;

            StringBuilder sb = new StringBuilder ();
            for (Question q : questionArrayList) {

                sb.append(q.getCurrentQuestion()).append("<br/>");
                sb.append("<h5>"+q.getAnswerList().size()+" Answers</h5>");
                sb.append("<div id='answer-"+numq+"'> </div>");
                sb.append("<button  style=\"margin-top:20px;\" value=\"answer_q\"     data-id = "+numq+" class=\"btn btn-primary\">Answer</button> ");
                sb.append("<button  style=\"margin-top:20px;\" value=\"show_answers\"   data-id = "+numq+"  class=\"btn btn-primary\">Show Answer</button><br>");
                sb.append("<br/>");

                numq++;

            }

            final String readyHtml = TemplateHandler.handleTemplate(TITLE, sb.toString(), this);

            out.write(readyHtml);
            out.close();

        } catch (Exception e) {
            e.printStackTrace();

        }

    }


    }

