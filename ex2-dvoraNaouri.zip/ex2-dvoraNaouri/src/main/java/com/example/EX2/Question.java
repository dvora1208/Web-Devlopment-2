package com.example.EX2;

import java.util.ArrayList;

/**
 * The type Question.
 */
public class Question {

    /**
     * Instantiates a new Question.
     *
     * @param questionIndex   the question index
     * @param currentQuestion the current question
     */
    public Question(int questionIndex , String currentQuestion ) {

        this.questionIndex = questionIndex;
        this.currentQuestion = currentQuestion;

    }

    /**
     * Gets current question.
     *
     * @return the current question
     */
    public String getCurrentQuestion() {
        return currentQuestion;
    }


    /**
     * Add answer.
     *
     * @param answer the answer
     */
    public void  addAnswer (Answer answer){
        answerList.add( answer);
        //chack if answer is valid
    }


    /**
     * Gets answer list.
     *
     * @return the answer list
     */
    public ArrayList<Answer> getAnswerList ()
    {
        return new ArrayList<Answer>(answerList);
    }

    /**
     * Gets question index.
     *
     * @return the question index
     */
    public int getQuestionIndex() {
        return questionIndex;
    }

    /**
     * The Current question.
     */
    String currentQuestion = "";
    /**
     * The Question index.
     */
    int questionIndex;

    /**
     * The Answer list.
     */
    ArrayList<Answer> answerList = new ArrayList<>();

}
