package com.example.EX2;

/**
 * Bean class for representing optional answer to survey
 */
public class Answer {

    private final String title;
    private final String userName;
    private final String indexQuestion;


    /**
     * Gets title.
     *
     * @return the answer
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets user name.
     *
     * @return the user name
     */
    public String getUserName() {
        return userName;
    }
    /**
     * Instantiates a new Answer.
     *
     * @param title         the answer
     * @param userName      the user name
     * @param indexQuestion the index question
     */
    public Answer(String title, String userName, String indexQuestion) {
        this.title = title;
        this.userName = userName;
        this.indexQuestion = indexQuestion;
    }
}
