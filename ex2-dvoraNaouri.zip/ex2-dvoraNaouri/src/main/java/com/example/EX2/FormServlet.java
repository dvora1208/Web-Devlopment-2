package com.example.EX2;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * The type Form servlet.
 *we get the number question and we print the form HTML with the ContentType
 *
 */
@WebServlet(name = "FormServlet", value = "/FormServlet")
public class FormServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        final String numq = request.getParameter("numq");

        try {


            Object showQuetion = getServletContext().getAttribute("ShowQuetion");
            ArrayList<Question> questionArrayList = (ArrayList<Question>) showQuetion;


            final int idQ = Integer.parseInt(numq);

            if (!Utile.validateIndex(numq, questionArrayList)) {
                throw new Exception();
            } else {

                final Question question = questionArrayList.get(idQ);
                final String htmlForm = TemplateHandler.
                        handleFormTemplate(idQ, question.getCurrentQuestion(), this);
                final String fullFormPage =
                        TemplateHandler.handleTemplate("Your answer", htmlForm, this);

                response.setContentType("text/html");
                final PrintWriter writer =
                        response.getWriter();

                writer.print(fullFormPage);
                writer.close();

            }


        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("/");
        }
    }

    }
