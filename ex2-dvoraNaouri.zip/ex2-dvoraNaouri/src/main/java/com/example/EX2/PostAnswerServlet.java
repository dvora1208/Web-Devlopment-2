package com.example.EX2;


import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.ArrayList;

/**
 * The type Post answer servlet.
 * we get the answer of the user and is name in variable and then we insert it in the
 * corect answer list.
 * Send replies to the server to update the server with data
 * And upload an answer to the server and keep it handled by adding an answer
 */
@WebServlet(name = "PostAnswerServlet", value = "/PostAnswerServlet")
public class PostAnswerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.sendRedirect("/");

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



       final String indexQuestion = request.getParameter("index-question");
        final String answer = request.getParameter("answer");
        final String name = request.getParameter("name");

        Answer userAnswer = new Answer(answer, name, indexQuestion );

        Object showQuetion = getServletContext().getAttribute("ShowQuetion");

        ArrayList<Question> questionArrayList = (ArrayList<Question>) showQuetion;



        try{

            if( Utile.validateIndex(indexQuestion, questionArrayList)){

                final int indexInteger = Integer.parseInt(indexQuestion);

                questionArrayList.get(indexInteger).addAnswer(userAnswer);
            }


        }finally {

            response.sendRedirect("/");
        }




    }
}
