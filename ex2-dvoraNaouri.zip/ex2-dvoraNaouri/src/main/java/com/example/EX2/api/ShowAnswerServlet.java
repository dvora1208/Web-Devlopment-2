package com.example.EX2.api;

import com.example.EX2.Answer;
import com.example.EX2.Question;
import com.example.EX2.Utile;
import com.google.gson.Gson;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * The type Show answer servlet.
 * 93 / 5000
 * Résultats de traduction
 * Show answers
 * Shows answers that already exist and displays them in the browser
 * This is the action of the
 * Rest api
 * Takes care of Jason
 */
@WebServlet(name = "ShowAnswerServlet", value = "/ShowAnswerServlet")
public class ShowAnswerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setHeader("Content-Type", "application/json");

        final String indexQuestion = request.getParameter("index-question");

        Object showQuetion = getServletContext().getAttribute("ShowQuetion");

        ArrayList<Question> questionArrayList = (ArrayList<Question>) showQuetion;


        try{

            if( Utile.validateIndex(indexQuestion, questionArrayList)){

                final int indexInteger = Integer.parseInt(indexQuestion);

                final ArrayList<Answer> answerList = questionArrayList.get(indexInteger).getAnswerList();

                final Gson gson = new Gson();
                final String jsonAnswer = gson.toJson(answerList);
                final PrintWriter writer = response.getWriter();
                writer.write(jsonAnswer);
                writer.close();
            }

        }finally {

            response.sendRedirect("/");
        }




    }
}
