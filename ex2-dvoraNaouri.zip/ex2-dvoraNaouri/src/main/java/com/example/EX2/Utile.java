package com.example.EX2;

import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * The type Utile.
 */
public class Utile {

    /**
     * Validate index boolean.
     * Handles a case of data overruns
     * @param indexQuestion     the index question
     * @param questionArrayList the question array list
     * @return the boolean
     */
    public static boolean validateIndex(String indexQuestion, ArrayList<Question> questionArrayList){

        final int idInteger = Integer.parseInt(indexQuestion);

        return idInteger >= 0 && idInteger < questionArrayList.size();



    }



}
