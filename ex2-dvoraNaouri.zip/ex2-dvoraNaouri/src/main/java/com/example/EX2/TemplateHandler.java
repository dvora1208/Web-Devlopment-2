package com.example.EX2;

import javax.servlet.http.HttpServlet;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

/**
 * The type Template handler.
 * Responsible for reading the constants in our case of HTML,
 * putting them into the appropriate servlet
 */
public class TemplateHandler {
  private static final String TEMPLATE_FILE_NAME = "home_header.html";
    private static final String FORM_FILE_NAME = "form_answer.html";

    /**
     * Handle template string.
     *
     * @param title     the answer
     * @param content   the content
     * @param myServlet the my servlet
     * @return the string
     * @throws FileNotFoundException the file not found exception
     */
    public static String handleTemplate(String title, String content, HttpServlet myServlet) throws FileNotFoundException {

        String templateText = getTemplate(myServlet,TEMPLATE_FILE_NAME );

        return templateText.replace("title-placeholder", title)
                .replace("content-placeholder", content);

    }


    /**
     * Handle form template string.
     *
     * @param id        the id of the question
     * @param question  the question
     * @param myServlet the my servlet
     * @return the string
     * @throws FileNotFoundException the file not found exception
     */
    public static String handleFormTemplate(int id, String question, HttpServlet myServlet) throws FileNotFoundException {

        String templateText = getTemplate(myServlet, FORM_FILE_NAME);

        return templateText.replace("index-placeholder", String.valueOf(id))
        .replace("question-placeholder", question);

    }

    /**
     *Receives the constant and the servlet and handles it accordingly.
     */
    private static String getTemplate( HttpServlet myServlet , String fileTemplateName) throws FileNotFoundException {
        final String homeHeader = myServlet.getServletContext().getRealPath(fileTemplateName);
        final Scanner scanner = new Scanner(new FileReader(homeHeader));
        StringBuilder sb = new StringBuilder();

        while(scanner.hasNextLine())
        {
            sb.append(scanner.nextLine());

        }

       return sb.toString();
    }


}
