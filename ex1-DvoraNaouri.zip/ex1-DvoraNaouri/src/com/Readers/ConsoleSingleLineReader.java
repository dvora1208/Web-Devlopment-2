package com.Readers;

import com.Globals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * class that read from the console.
 */
public class ConsoleSingleLineReader implements InputSupplier, AutoCloseable{

    private final Scanner scan = new Scanner(System.in);

    /**
     * class that read from the console, enter it to list and return the list.
     * @return list of strings.
     * @throws InputSupplierException
     */
    @Override
    public List<String> getInputs() throws InputSupplierException {

        List<String> line = new ArrayList<>();
        try {

            scan.useDelimiter("\n");
            String l = scan.next();
            line.add(l);
        } catch (Exception e) {
            throw new InputSupplierException(e.getMessage());
        }
        return line;
    }

    /**
     * closing the scanner object.
     */
    @Override
    public void close() {
        scan.close();
    }
}
