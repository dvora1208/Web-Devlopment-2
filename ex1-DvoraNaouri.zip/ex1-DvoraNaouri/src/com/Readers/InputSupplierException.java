package com.Readers;

/**
 * class that inherite from exeption class.
 */
public class InputSupplierException extends Exception {
    public InputSupplierException() {

        }

    /**
     * ctor of the class
     * @param cause String
     */
    public InputSupplierException(final String cause) {
            super(cause);
        }

    }
