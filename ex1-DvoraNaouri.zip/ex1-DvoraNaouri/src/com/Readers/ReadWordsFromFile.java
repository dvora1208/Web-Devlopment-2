package com.Readers;

import com.Globals;
import com.Readers.InputSupplier;
import com.Readers.InputSupplierException;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * class to read words from file
 */
public class ReadWordsFromFile implements InputSupplier {
    private String m_file_path;

    /**
     * ctor of the class
     * @param file_path
     * @throws InputSupplierException
     */
    public ReadWordsFromFile(String file_path) throws InputSupplierException {
        File file = new File(file_path);
        if (!file.exists())
            throw new InputSupplierException(String.format("File: %s does not exist", file_path));
         this.m_file_path = file_path;
    }


    /**
     * function that read all the words from file and store it in list.
     * @return list of strings.
     * @throws InputSupplierException
     */
    @Override
    public List<String> getInputs() throws InputSupplierException {
        BufferedReader br = null;
        List<String> words = new ArrayList<>();
        try {
             br = new BufferedReader(new FileReader(this.m_file_path));
             String line = br.readLine();
             while (line != null) {
                 line = line.toLowerCase();

                 words.addAll(Arrays.asList(line.split(" ")));
                 line = br.readLine();
             }
        }catch (FileNotFoundException e){
                throw new InputSupplierException("file not found");
        } catch (IOException e) {
            throw new InputSupplierException("error reading from file");
        } finally {
            if(br != null) {
                try {
                    br.close();
                } catch (IOException ignore) {

                }
            }
        }

        return words;
    }
}
