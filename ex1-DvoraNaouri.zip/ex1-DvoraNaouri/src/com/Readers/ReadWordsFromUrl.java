package com.Readers;

import org.jsoup.Jsoup;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * class to read words from url
 */
public class ReadWordsFromUrl implements InputSupplier {
    private String url_path;
    private String seperator;

    /**
     * ctor of the class
     * @param url
     * @param seperator
     */
    public ReadWordsFromUrl(String url, String seperator) {
        this.url_path = url;
        this.seperator = seperator;
    }


    /**
     * function that read all the words from url and store it in list.
     * @return list of strings.
     * @throws InputSupplierException
     */
    @Override
    public List<String> getInputs() throws InputSupplierException {
        List<String> words = null;
        try
        {
            String html = Jsoup.connect(url_path).get().body().text();

            String[] inputs = html.split(seperator);
            words = new LinkedList<>(Arrays.asList(inputs));
            words.replaceAll(String::trim);
            words.removeAll(Collections.singleton(""));
        }

        catch (MalformedURLException e) {
            throw new InputSupplierException("bad url"); }
        catch (IOException e) {
            throw new InputSupplierException("error");
        }


        return words;
    }
}
