

package com;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;


/**
 * URLFilter class
 */
public class URLFilter {
    private char type;
    private String URL_path;
    private List<String> arguments = null;
    private URL url;

    /**
     * function that build the command from the user.
     * @param type String
     * @param url String
     * @param arguments List
     * @throws URLFilterArgException
     */
    private void set(String type, String url, List<String> arguments) throws URLFilterArgException {
        setType(type);
        if(this.type == 'q') return;
        setURL_path(url);
        setArguments(arguments);
    }

    /**
     * return the type of the command.
     * @return char
     */
    char getType() {return this.type;}

    /**
     * ctor of the class
     * @param raw_input String
     * @throws URLFilterArgException
     */
    public URLFilter(String raw_input) throws URLFilterArgException {
        if(raw_input.strip().equals("") || raw_input.strip().length() == 0)
            throw new URLFilterArgException("cannot have empty string as input");

        List<String> inputs = clean_user_input(raw_input);
        List<String> args = inputs.size() >= 3 ? inputs.subList(2, inputs.size()):null;
        this.set(inputs.get(0), inputs.size() >= 2? inputs.get(1):" ",args);
    }

    /**
     * clear the command from unnececery strings.
     * @param raw_input String
     * @return List
     */
    private List<String> clean_user_input(String raw_input)
    {
        String[] inputs = raw_input.split(Globals.WORD_SEPERATOR);
        List<String> strings = new LinkedList<>(Arrays.asList(inputs));
        strings.replaceAll(String::trim);
        strings.removeAll(Collections.singleton(""));
        return strings;
    }

    /**
     * set the type of the command.
     * @param type
     * @throws URLFilterArgException
     */
    private void setType(String type) throws URLFilterArgException {
        if(type.length() !=1)
            throw new URLFilterArgException("The type of the URL filter must be a single char");

        if(!"twilq".contains(type))
            throw new URLFilterArgException("The type of command: " + type + " is not known");

        this.type = type.charAt(0);

    }

    /**
     * set the url path of the command.
     * @param url
     * @throws URLFilterArgException
     */
    private void setURL_path(String url) throws URLFilterArgException {
        if(url.strip().equals("") && this.type!='q')
            throw new URLFilterArgException("URL cannot be empty");


        this.URL_path = url;
        try {
            this.url = new URL(url);
        } catch (MalformedURLException e) {
            throw new URLFilterArgException("bad url");
        }


    }

    /**
     * set the argument of the command from the user.
     * @param args
     * @throws URLFilterArgException
     */
    private void setArguments(List<String> args) throws URLFilterArgException {
        this.arguments = args;
    }

    /**
     * Sets new type.
     *
     * @param type New value of type.
     */
    public void setType(char type) {
        this.type = type;
    }

    /**
     * Gets url.
     *
     * @return Value of url.
     */
    public URL getUrl() {
        return url;
    }

    /**
     * Sets new url.
     *
     * @param url New value of url.
     */
    public void setUrl(URL url) {
        this.url = url;
    }

    public String getURL_path() {
        return URL_path;
    }

    /**
     * Gets arguments.
     *
     * @return Value of arguments.
     */
    public List<String> getArguments() {
        return arguments;
    }
}