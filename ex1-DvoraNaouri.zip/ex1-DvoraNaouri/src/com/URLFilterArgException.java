package com;

/**
 * class that throw exception relate to urlfilter.
 */
public class URLFilterArgException extends Exception {
    public URLFilterArgException() {

    }

    /**
     * ctor of the class.
     * @param cause
     */
    public URLFilterArgException(final String cause) {
        super(cause);
    }

}
