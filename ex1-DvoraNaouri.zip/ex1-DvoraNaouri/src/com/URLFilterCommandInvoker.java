package com;


import com.Commands.*;

/**
 * class that execute the commands.
 */
public class URLFilterCommandInvoker {
    /**
     * function that takes the command from the user and execute it throw the right class and command
     * @param urlFilter
     * @param proxy
     * @return boolean if success.
     * @throws URLFilterCommandException
     */
    boolean execute(URLFilter urlFilter, WebProxy proxy) throws URLFilterCommandException {
        Command c;
        switch (urlFilter.getType())
        {
            case 'q':
                proxy.setExit(true);
                return false;

            case 't':
                c = new ContentCommand();
                break;

            case 'w':
                c = new SearchWordCommand();
                break;
            case 'i':
                c = new ImageCommand();
                break;
            case 'l':
                try {
                    c = new LanguageCommand(urlFilter);
                    break;
                }catch (URLFilterCommandException e){return false;}

            default:
                throw new URLFilterCommandException("invalid command");
        }
        return c.execute(urlFilter);
    }
}
