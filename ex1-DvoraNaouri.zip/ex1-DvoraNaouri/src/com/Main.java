package com;

import com.Readers.ConsoleSingleLineReader;

public class Main {

    public static void main(String[] args) {

        try {
            WebProxy wp = new WebProxy(new ConsoleSingleLineReader());
            wp.execute();
        } catch (Exception e) {
            e.printStackTrace();

        }


    }


}
