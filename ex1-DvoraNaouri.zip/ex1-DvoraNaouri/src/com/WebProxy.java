package com;

import com.Commands.URLFilterCommandException;
import com.Readers.InputSupplier;
import com.Readers.InputSupplierException;

import java.util.List;

/**
 * main class to ask user for command.
 */
public class WebProxy {
    private InputSupplier m_input_supplier = null;
    private URLFilterCommandInvoker commandInvoker;
    private boolean exit = false;

    /**
     * ctor of the class.
     * @param input
     */
    WebProxy(InputSupplier input)
    {
        m_input_supplier = input;
        commandInvoker  = new URLFilterCommandInvoker();
    }


    /**
     * execute command to start the program.
     * @throws InputSupplierException
     */
    public void execute() throws InputSupplierException {
        while(!exit)
        {
            try {
                System.out.println("Enter a command:");
                List<String> user_input = m_input_supplier.getInputs();
                URLFilter urlFilter;
                urlFilter = new URLFilter(user_input.get(0));
                boolean res = commandInvoker.execute(urlFilter, this);
                if(urlFilter.getType() == 'q') break;
                System.out.println(res? "true":"false");
            } catch (URLFilterArgException | URLFilterCommandException e) {
                System.out.println(e.getMessage());
            }

        }
    }

    /**
     * function that set the value of exit field.
     * @param val
     */
    public void setExit(boolean val){exit = val;}

}
