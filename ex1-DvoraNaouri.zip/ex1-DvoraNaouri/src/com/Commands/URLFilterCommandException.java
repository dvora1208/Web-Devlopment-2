package com.Commands;


/**
 * exception class for url filter command.
 */
public class URLFilterCommandException extends Exception{

    public URLFilterCommandException() {

    }

    /**
     * constructor that gets string and raise a command.
     * @param cause String
     */
    public URLFilterCommandException(final String cause) {
        super(cause);
    }

}
