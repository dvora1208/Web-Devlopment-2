package com.Commands;

import com.Readers.InputSupplierException;
import com.Readers.ReadWordsFromFile;
import com.Readers.ReadWordsFromUrl;
import com.URLFilter;
import com.URLFilterArgException;

import java.util.List;

/**
 * class wrap the command function to search all the words in html and file.
 */
public class SearchWordCommand implements Command{

    /**
     * function command that check if all words in file is in the html page.
     * @param urlFilter contain all the data of the command.
     * @return boolean
     * @throws URLFilterCommandException
     */
    @Override
    public boolean execute(URLFilter urlFilter) throws URLFilterCommandException{
        try {
            String url_path = urlFilter.getURL_path();
            String file_path = urlFilter.getArguments().get(0);
            ReadWordsFromFile readWordsFromFile = new ReadWordsFromFile(file_path);
            List<String> words_file = readWordsFromFile.getInputs();

            if (words_file.isEmpty())
                return true;

            ContentCommand contentCommand = new ContentCommand();
            URLFilter urlFilter1 = new URLFilter("t " + url_path + " text");

            if (!contentCommand.execute(urlFilter1))
                return false;

            ReadWordsFromUrl readWordsFromUrl = new ReadWordsFromUrl(url_path, " ");
            List<String> words_url = readWordsFromUrl.getInputs();

            if (words_url == null)
                return false;

            for (String word_file : words_file) {
                if (!words_url.contains(word_file))
                    return false;
            }

        }catch (InputSupplierException | URLFilterArgException e) {
            throw new URLFilterCommandException("error");
        }

        return true;
    }
}
