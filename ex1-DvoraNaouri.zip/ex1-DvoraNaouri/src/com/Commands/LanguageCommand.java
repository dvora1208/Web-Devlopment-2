package com.Commands;

import com.Globals;
import com.Readers.ReadWordsFromUrl;
import com.URLFilter;
import java.util.*;

/**
 * class that wrap the command function to check what language the page is written.
 */
public class LanguageCommand implements Command{

    private Map<Character, Double> m_freq_map;
    private int m_content_length;
    private URLFilter m_URL_filter;

    /**
     * function to check what language the page is written(only for english letters).
     * @param urlFilter contain all the data of the command.
     * @return boolean
     */
    @Override
    public boolean execute(URLFilter urlFilter) {
        return variance_compare_algorithm(m_freq_map, Globals.english_freq_map, Globals.frequency_comparitor_threshhold);
    }

    /**
     * constructor of the class.
     * @param f contain all the data of the command.
     * @throws URLFilterCommandException
     */
    public LanguageCommand(URLFilter f) throws URLFilterCommandException {
        if(f.getArguments().size() != 1 ||!f.getArguments().contains("english") )
            throw new URLFilterCommandException("invalid arguments");
        m_URL_filter = f;
        m_freq_map = new HashMap<>();
        m_content_length = 0;
        initialize_freq_map();
    }

    /**
     * function to go over the html page and init the freq map.
     * @throws URLFilterCommandException
     */
    private void initialize_freq_map() throws URLFilterCommandException {
        ReadWordsFromUrl readWordsFromUrl = new ReadWordsFromUrl(m_URL_filter.getURL_path(), "");
        try {
            List<String> letters = readWordsFromUrl.getInputs();
            for(String c : letters)
            {
                c = c.strip();
//

                //if it is empty or a number or a special char, then it can be any language and we skip.
                if(c.equals("") || c.matches("-?\\d+(\\.\\d+)?"))
                    continue;

                m_content_length++;

                if(isEnglishLetter(c.charAt(0))) {

                    String ch = c.toUpperCase();
                    if (!m_freq_map.containsKey(ch.charAt(0)))
                        m_freq_map.put(ch.charAt(0), 1.0);
                    else
                        m_freq_map.put(ch.charAt(0), m_freq_map.get(ch.charAt(0)) + 1);
                }

            }


            for (Map.Entry<Character, Double> entry : m_freq_map.entrySet() )
                entry.setValue(entry.getValue()/(double)m_content_length);

        } catch (Exception e) {
            throw new URLFilterCommandException(e.getMessage());
        }

    }

    /**
     * function that check if letter is an english letter.
     * @param c character
     * @return boolean
     */
    private boolean isEnglishLetter(char c) {
        return (c >= 'a' && c <= 'z') ||
                (c >= 'A' && c <= 'Z') ;
    }

    /**
     * function that check the variance between the frequency map and the probility map of english letters.
     * @param f
     * @param F
     * @param threshold
     * @return boolean
     */
    private boolean variance_compare_algorithm(Map<Character, Double> f, Map<Character, Double> F, double threshold)
    {
        double var = 0;


        for(char c : f.keySet())
        {
            double Fi = F.getOrDefault(c, 0.0);
            double fi = f.getOrDefault(c, 0.0);
            double single_delta = Math.pow(Math.abs(Fi -fi),2);
            var+= single_delta;

        }

        return var <= threshold;
    }
}
