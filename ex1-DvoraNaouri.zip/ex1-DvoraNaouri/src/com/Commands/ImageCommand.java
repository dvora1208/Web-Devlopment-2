package com.Commands;

import com.URLFilter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


import java.io.IOException;

/**
 * class that wrap the command that check the img tag in html page
 */
public class ImageCommand implements Command{

    /**
     * function that check if an html page has images.
     * @param urlFilter contain all the data of the command.
     * @return boolean
     * @throws URLFilterCommandException
     */
    @Override
    public boolean execute(URLFilter urlFilter) throws URLFilterCommandException {
        Document doc = null;
        try {
            doc = Jsoup.connect(urlFilter.getURL_path()).get();
            Element element = doc.selectFirst("img");
            return element != null;
        } catch (IOException e) {
            throw new URLFilterCommandException(e.getMessage());
        }

    }
}
