package com.Commands;

import com.URLFilter;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;

/**
 * class that wrap a function command that check if http start with the same type
 */
public class ContentCommand implements Command{

    /**
     * command execution function that check the header of http and return true
     * if the field of the content-type start with the same of the argument.
     * @param urlFilter contain all the data of the command.
     * @return boolean
     * @throws URLFilterCommandException
     */
    @Override
    public boolean execute(URLFilter urlFilter) throws URLFilterCommandException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection)  urlFilter.getUrl().openConnection();
            connection.setRequestMethod("HEAD");
            connection.connect();
            String contentType = connection.getContentType();

            if(urlFilter.getArguments() == null || !contentType.startsWith(urlFilter.getArguments().get(0)))
                return false;

        } catch (MalformedURLException e) {
            throw new URLFilterCommandException("bad url");
        } catch (IOException e) {
            throw new URLFilterCommandException("error");
        } finally {
            if(connection != null)
                connection.disconnect();
        }

        return true;
    }
}
