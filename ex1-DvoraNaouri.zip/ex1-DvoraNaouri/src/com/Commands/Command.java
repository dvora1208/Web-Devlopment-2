package com.Commands;

import com.URLFilter;

/**
 * interface class that execute a command.
 */
public interface Command {
    /**
     * function that execute the command.
     * @param urlFilter contain all the data of the command.
     * @return boolean
     * @throws URLFilterCommandException
     */
    boolean execute(URLFilter urlFilter) throws URLFilterCommandException;
}
