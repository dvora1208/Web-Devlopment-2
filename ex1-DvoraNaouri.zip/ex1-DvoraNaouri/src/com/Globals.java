package com;

import java.util.HashMap;
import java.util.Map;

/**
 * class Globals that every class needs.
 */
public class Globals {
    public static final String WORD_SEPERATOR = " ";
    public static final double frequency_comparitor_threshhold = 0.04;
    public static final Map<Character, Double> english_freq_map = new HashMap<Character, Double>() {{
        put('A', 0.0748);
        put('B', 0.0134);
        put('C', 0.0411);
        put('D', 0.0308);
        put('E', 0.1282);
        put('F', 0.0240);
        put('G', 0.0185);
        put('H', 0.0414);
        put('I', 0.0725);
        put('J', 0.0014);
        put('K', 0.0053);
        put('L', 0.0403);
        put('M', 0.0340);
        put('N', 0.0673);
        put('O', 0.0785);
        put('P', 0.0314);
        put('Q', 0.0010);
        put('R', 0.0609);
        put('S', 0.0614);
        put('T', 0.1002);
        put('U', 0.0316);
        put('V', 0.0108);
        put('W', 0.0131);
        put('X', 0.0044);
        put('Y', 0.0127);
        put('Z', 0.0011);}};


}
