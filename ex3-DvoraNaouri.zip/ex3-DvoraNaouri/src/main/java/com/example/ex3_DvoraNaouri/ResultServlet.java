package com.example.ex3_DvoraNaouri;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The type Result servlet.
 * print the result in live to the user ,
 * at the end Updates the user who has completed a process and offers a link back to the main page
 * exception it throw if the data is null we get an exception and we return to the main servlet
 */
@WebServlet(name = "ResultServlet", value = "/ResultServlet")

public class ResultServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        final PrintWriter writeToUser = response.getWriter();

        final ConcurrentHashMap<Integer,Data> dataBase =
                (ConcurrentHashMap<Integer,Data>) getServletContext().getAttribute("dataBase");
        try {
            final int requestId = Integer.parseInt(request.getParameter("requestId"));
             Data data = dataBase.get(requestId);

            if(data==null){
                throw new InvalidRequestIdException();
            }
            int numOfImages = data.getNumOfImages();
            writeToUser.write("until now we found " + numOfImages + " image/s");

            final boolean threadIsRunning = !data.isEndProcess();
            if (threadIsRunning ) {

                writeToUser.write("crawling, please reload <a href= '' > this page </a> later for final results");
            } else {
                writeToUser.write("Thread done!");
                writeToUser.write(" <a href='/'> click here to the form </a>");
            }
        }catch (NumberFormatException| InvalidRequestIdException e ){
           response.sendRedirect("/hello-servlet");
        }

    }


    private static class InvalidRequestIdException extends Exception{

    }


}
