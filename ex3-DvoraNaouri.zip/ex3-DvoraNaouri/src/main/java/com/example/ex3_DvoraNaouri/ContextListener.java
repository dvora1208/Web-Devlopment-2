package com.example.ex3_DvoraNaouri;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The type Context listener.
 */
@WebListener
public class ContextListener implements ServletContextListener{

    /**
     * Instantiates a new Context listener.
     * we define a context listener for tha data base
     */
    public ContextListener() {
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        sce.getServletContext().setAttribute("dataBase", new ConcurrentHashMap<Integer,Data>());
        /* This method is called when the servlet context is initialized(when the Web application is deployed). */
    }



}
