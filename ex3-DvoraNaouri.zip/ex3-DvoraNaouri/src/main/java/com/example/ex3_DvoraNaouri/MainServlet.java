package com.example.ex3_DvoraNaouri;

import org.jsoup.Connection;
import org.jsoup.Jsoup;

import java.io.*;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

/**
 * The type Main servlet.Responsible for printing the results on the user's screen
 * he basically pulls the results from the data structure and prints them.
 * he save in a static parameter  the url that sended by the user.(without space)
 *  Extraction of elements (image and links from the URL ), we save a string with the maximum depth.
 *  Checks if the connection was made as required otherwise throws an exception.
 *  if all is correct we Update the user that the run is started, we print the number of picture with
 *  the result server.
 *
 */

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class MainServlet extends HttpServlet {
    /**
     * The constant PARAMURL.
     */
    public static final String PARAMURL = "myUrl";
    private String message;
    private static int requestId=0;


    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=UTF-8");

        final String myUrl = request.getParameter(PARAMURL).trim();
        final PrintWriter writeToUser = response.getWriter();
        final Connection.Response jsoupResponse = Jsoup.connect(myUrl).execute();
        final int statusCode = jsoupResponse.statusCode();
        final String maxDepth = getServletContext().getInitParameter("maxdepth");
        final int maximalDepth = Integer.parseInt(maxDepth);


        if (statusCode==200){
            final ConcurrentHashMap<Integer, Data > dataBase = (ConcurrentHashMap<Integer, Data >)
            getServletContext().getAttribute("dataBase");
            dataBase.put(requestId ,new Data() );

            final int currentRequestId = requestId;

            new Crawling(jsoupResponse, maximalDepth, new Crawling.Listener() {
                @Override
                public void foundImages(int numOfImages) {

                    dataBase.get(currentRequestId).setNumOfImages(dataBase.get(currentRequestId).getNumOfImages()+numOfImages);

                }

                @Override
                public void endProcess() {
                   dataBase.get(currentRequestId).setEndProcess(true);
                }

            }).start();

            writeToUser.write("the run is started <a href='/ResultServlet?requestId="+requestId+"'>" +

                    " click here for the result </a>");

            requestId++;
        }

        else {

            writeToUser.write("Request denied, please try again or check the URL address");
        }

        writeToUser.close();
    }

    public void destroy() {
    }
}