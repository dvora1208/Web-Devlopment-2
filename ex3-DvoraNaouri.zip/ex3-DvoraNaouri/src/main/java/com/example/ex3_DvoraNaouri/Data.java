package com.example.ex3_DvoraNaouri;

/**
 * The type Data.
 */
public class Data {
    private int numOfImages;
    private boolean endProcess ;

    /**
     * Gets num of images.
     *
     * @return the num of images
     */
    public int getNumOfImages() {
        return numOfImages;
    }

    /**
     * Sets num of images.
     *
     * @param numOfImages the num of images
     */
    public void setNumOfImages(int numOfImages) {
        this.numOfImages = numOfImages;
    }

    /**
     * Is end process boolean.
     *
     * @return the boolean
     */
    public boolean isEndProcess() {
        return endProcess;
    }

    /**
     * Sets end process.
     *
     * @param endProcess the end process
     */
    public void setEndProcess(boolean endProcess) {
        this.endProcess = endProcess;
    }
}
