package com.example.ex3_DvoraNaouri;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.HashSet;


/**
 * The type Crawling.
 * Here we basically have responsibility functions for scanning links for multiple images for each link.
 */
public class Crawling extends Thread {
    //response to the user from server
    private Connection.Response responseFromServer;
    private HashSet<String> usereUrls = new HashSet<String>();
    private  int maximalDepth;
    private final Listener listener;

    /**
     * The interface Listener.
     */
    public  interface Listener {
        /**
         * Found images.
         *
         * @param numOfImages the num of images
         */
        void foundImages(int numOfImages);

        /**
         * End process.
         */
        void endProcess();
    }

    /**
     * Instantiates a new Crawling.
     *
     * @param responseFromServer the response from server
     * @param maximalDepth       the maximal depth
     * @param listener           the listener
     */
    public Crawling(Connection.Response responseFromServer, int maximalDepth, Listener listener) {
        this.responseFromServer = responseFromServer;
        this.maximalDepth = maximalDepth;
        this.listener = listener;
    }

    @Override
    public void run() {
        super.run();
        parse(responseFromServer);

    }
    /**
     *
     * parse the url that the user send to count how many picture and links are in this url
     */

    private void parse(Connection.Response responseFromServer) {

        try {
            final Document parse = responseFromServer.parse();

            final int imageCount = parse.getElementsByTag("img").size();

           listener.foundImages(imageCount);
         conect (parse);

        } catch (IOException e) {

        }

    }
    /**
     *  every link he chack how many image are in the new link by call the parse function
     *  if we didnt get the image size or to pares from the other server we get exception
     */

    private void conect(Document parse) throws IOException {
        final Elements Links = parse.getElementsByTag("a");

        if (maximalDepth<0){
            listener.endProcess();
            return;
        }
        for (Element link : Links){
            String attributUrl = link.attr("abs:href");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if( attributUrl.endsWith("#")){
                attributUrl=attributUrl.substring(0,attributUrl.length()-1);
            }
            if (usereUrls.contains(attributUrl)){
                continue;
            }
            else{
                usereUrls.add(attributUrl);
            }
            System.out.println(attributUrl);
            final Connection connection = Jsoup.connect(attributUrl);
            //execute - jsoup response
            final Connection.Response execute = connection.execute();
            final int statusCode = execute.statusCode();
            if (statusCode==200){
               parse(execute);
            }
        //if the status is not 200 so the image will be 0 and its OK
        }
        maximalDepth--;
    }

}
